package bobosinoe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.border.EmptyBorder;

/**
 * Meal customization screen — shown as a modal JDialog.
 * Add-ons (sides, beverages, desserts) are now loaded from the DB,
 * so each choice carries a real productId.
 */
public class MealCustomizer extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM     = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE       = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK  = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK_SIDEBAR = new Color(0x1C, 0x1C, 0x1E);
    private static final Color CARD_WHITE   = Color.WHITE;
    private static final Color BORDER_SOFT  = new Color(0xE5, 0xE0, 0xD8);
    private static final Color SELECTED_BG  = new Color(0xFF, 0xEC, 0xD5);
    private static final Color SELECTED_BD  = new Color(0xE8, 0x73, 0x0A);

    // ── Inner class: one add-on option loaded from DB ─────────────
    private static class ProductOption {
        final int    id;
        final String name;
        final double price;

        ProductOption(int id, String name, double price) {
            this.id    = id;
            this.name  = name;
            this.price = price;
        }

        String addonStr() {
            return price == 0 ? "+0" : String.format("+%.0f", price);
        }
    }

    private static final String[] STEP_LABELS    = {"🥗 Sides", "🥤 Beverage", "🍮 Dessert"};
    private static final String[] STEP_SUBTITLES = {
        "Choose a side dish for your meal",
        "Choose a beverage to go with it",
        "Choose a dessert  (optional)"
    };
    private static final String[] DB_CATEGORIES  = {"Sides", "Beverages", "Desserts"};

    // ── State ─────────────────────────────────────────────────────
    private final Menu           menuOwner;
    private final CheckoutScreen checkoutOwner;
    private final int            editIndex;

    private final String baseItemName;
    private final double baseItemPrice;
    private final int    productId;

    private int    currentStep = 0;

    // Selected add-on per step (null = nothing chosen yet)
    private ProductOption selectedSide;
    private ProductOption selectedDrink;
    private ProductOption selectedDessert;

    // Cache loaded options so we don't re-query on sidebar clicks
    private final List<ProductOption>[] optionCache = new List[3];

    private final JButton[] selectedCards = new JButton[3];

    private JPanel  itemPanel;
    private JLabel  lblStepTitle;
    private JLabel  lblStepSub;
    private JButton addToCartBtn;
    private JButton[] sidebarBtns;

    // ── Constructor: new order from Menu ──────────────────────────
    public MealCustomizer(Menu menuOwner, String itemName, double basePrice,
                          int productId, CheckoutScreen unused) {
        super(menuOwner, "Josie's Cafe – Customize Your Meal", true);
        this.menuOwner     = menuOwner;
        this.checkoutOwner = null;
        this.editIndex     = -1;
        this.baseItemName  = itemName;
        this.baseItemPrice = basePrice;
        this.productId     = productId;
        buildUI();
    }

    // ── Constructor: edit existing cart item from CheckoutScreen ──
    public MealCustomizer(Menu menuOwner, CartItem existing, int cartIndex,
                          CheckoutScreen checkoutOwner) {
        super(menuOwner, "Josie's Cafe – Edit Your Meal", true);
        this.menuOwner     = menuOwner;
        this.checkoutOwner = checkoutOwner;
        this.editIndex     = cartIndex;
        this.baseItemName  = existing.baseItemName;
        this.baseItemPrice = existing.baseItemPrice;
        this.productId     = existing.productId;
        // Pre-fill will be resolved after DB load in loadStep()
        // We store the IDs so we can match them after loading
        this._preFillSideId    = existing.sideId;
        this._preFillDrinkId   = existing.drinkId;
        this._preFillDessertId = existing.dessertId;
        buildUI();
    }

    // Temporary holders used only by the edit constructor
    private int _preFillSideId    = -1;
    private int _preFillDrinkId   = -1;
    private int _preFillDessertId = -1;

    // ── Load options from DB ──────────────────────────────────────
    @SuppressWarnings("unchecked")
    private List<ProductOption> loadOptions(int step) {
        if (optionCache[step] != null) return optionCache[step];

        List<ProductOption> list = new ArrayList<>();
        String sql = "SELECT side_id, addonName, price FROM addons WHERE category = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, DB_CATEGORIES[step]);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ProductOption(
                    rs.getInt("side_id"),
                    rs.getString("addonName"),
                    rs.getDouble("price")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        optionCache[step] = list;
        return list;
    }

    // ── UI construction ───────────────────────────────────────────
    private void buildUI() {
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(520, 680);
        setLocationRelativeTo(menuOwner);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // Header
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 0));
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(520, 75));
        header.setBorder(new EmptyBorder(10, 10, 10, 10));

        String headerTitle = (editIndex >= 0) ? "Edit Your Meal" : "Customize Your Meal";
        JLabel lblTitle = new JLabel(headerTitle, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblBase = new JLabel(
            "Base: " + baseItemName + "  ·  ₱" + String.format("%.2f", baseItemPrice),
            SwingConstants.CENTER);
        lblBase.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblBase.setForeground(new Color(0xFF, 0xE0, 0xC0));

        header.add(lblTitle);
        header.add(lblBase);
        root.add(header, BorderLayout.NORTH);

        // Sidebar
        JPanel sidebar = new JPanel(new GridLayout(3, 1, 0, 0));
        sidebar.setBackground(DARK_SIDEBAR);
        sidebar.setPreferredSize(new Dimension(130, 0));
        sidebarBtns = new JButton[3];
        for (int i = 0; i < 3; i++) {
            sidebarBtns[i] = createSidebarBtn(STEP_LABELS[i]);
            sidebar.add(sidebarBtns[i]);
        }
        root.add(sidebar, BorderLayout.WEST);

        // Center
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG_CREAM);

        JPanel stepHeader = new JPanel(new GridLayout(2, 1, 0, 2));
        stepHeader.setBackground(BG_CREAM);
        stepHeader.setBorder(new EmptyBorder(16, 20, 8, 20));
        lblStepTitle = new JLabel();
        lblStepTitle.setFont(new Font("Georgia", Font.BOLD, 16));
        lblStepTitle.setForeground(DARK_SIDEBAR);
        lblStepSub = new JLabel();
        lblStepSub.setFont(new Font("SansSerif", Font.ITALIC, 12));
        lblStepSub.setForeground(new Color(0x99, 0x99, 0x99));
        stepHeader.add(lblStepTitle);
        stepHeader.add(lblStepSub);
        center.add(stepHeader, BorderLayout.NORTH);

        itemPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        itemPanel.setBackground(BG_CREAM);
        itemPanel.setBorder(new EmptyBorder(4, 16, 16, 16));

        JScrollPane scroll = new JScrollPane(itemPanel);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        center.add(scroll, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        // Add / Save button
        addToCartBtn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isEnabled()
                    ? (getModel().isRollover() ? ORANGE_DARK : ORANGE)
                    : new Color(0xCC, 0xCC, 0xCC));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 0, 0);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        String btnLabel = (editIndex >= 0) ? "Save Changes" : "Add to Cart";
        addToCartBtn.setText(btnLabel + "  ·  ₱" + String.format("%.2f", baseItemPrice));
        addToCartBtn.setContentAreaFilled(false);
        addToCartBtn.setBorderPainted(false);
        addToCartBtn.setFocusPainted(false);
        addToCartBtn.setForeground(Color.WHITE);
        addToCartBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        addToCartBtn.setPreferredSize(new Dimension(0, 60));
        addToCartBtn.setEnabled(false);
        addToCartBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addToCartBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { addToCartBtn.repaint(); }
            public void mouseExited(MouseEvent e)  { addToCartBtn.repaint(); }
        });
        addToCartBtn.addActionListener(e -> finalizeMeal());
        root.add(addToCartBtn, BorderLayout.SOUTH);

        loadStep(0);
    }

    private void loadStep(int step) {
        currentStep = step;
        highlightSidebar(step);
        lblStepTitle.setText(STEP_LABELS[step]);
        lblStepSub.setText(STEP_SUBTITLES[step]);

        itemPanel.removeAll();

        // Load from DB (cached after first load)
        List<ProductOption> options = loadOptions(step);

        // Which ID are we pre-selecting? (edit mode)
        int preFillId = switch (step) {
            case 0 -> _preFillSideId;
            case 1 -> _preFillDrinkId;
            case 2 -> _preFillDessertId;
            default -> -1;
        };

        // Which option is already chosen? (user already selected this step)
        ProductOption alreadyChosen = switch (step) {
            case 0 -> selectedSide;
            case 1 -> selectedDrink;
            case 2 -> selectedDessert;
            default -> null;
        };

        for (ProductOption opt : options) {
            JButton card = createOptionCard(opt.name, opt.addonStr(), step);

            // Pre-select if editing (match by ID) or already chosen (match by ID)
            boolean shouldSelect =
                (alreadyChosen != null && alreadyChosen.id == opt.id) ||
                (alreadyChosen == null && preFillId != -1 && preFillId == opt.id);

            if (shouldSelect) {
                card.putClientProperty("selected", true);
                selectedCards[step] = card;
                // Also set the selection state
                switch (step) {
                    case 0 -> selectedSide    = opt;
                    case 1 -> selectedDrink   = opt;
                    case 2 -> selectedDessert = opt;
                }
            }

            card.addActionListener(e -> onCardSelected(card, opt, step));
            itemPanel.add(card);
        }

        if (options.isEmpty()) {
            itemPanel.add(new JLabel("No items found in database.", SwingConstants.CENTER));
        }

        // Enable finish button only on dessert step if something selected
        if (step == 2) {
            boolean ready = selectedDessert != null;
            addToCartBtn.setEnabled(ready);
            if (ready) updateCartBtnPrice();
        } else {
            addToCartBtn.setEnabled(false);
        }
        addToCartBtn.repaint();

        itemPanel.revalidate();
        itemPanel.repaint();
    }

    private void onCardSelected(JButton card, ProductOption opt, int step) {
        if (selectedCards[step] != null) {
            selectedCards[step].putClientProperty("selected", false);
            selectedCards[step].repaint();
        }
        card.putClientProperty("selected", true);
        card.repaint();
        selectedCards[step] = card;

        switch (step) {
            case 0 -> { selectedSide  = opt; autoAdvanceAfterDelay(1); }
            case 1 -> { selectedDrink = opt; autoAdvanceAfterDelay(2); }
            case 2 -> {
                selectedDessert = opt;
                addToCartBtn.setEnabled(true);
                addToCartBtn.repaint();
                updateCartBtnPrice();
            }
        }
    }

    private void autoAdvanceAfterDelay(int nextStep) {
        Timer t = new Timer(350, e -> loadStep(nextStep));
        t.setRepeats(false);
        t.start();
    }

    private void updateCartBtnPrice() {
        double running = baseItemPrice
            + (selectedSide    != null ? selectedSide.price    : 0)
            + (selectedDrink   != null ? selectedDrink.price   : 0)
            + (selectedDessert != null ? selectedDessert.price : 0);
        String btnLabel = (editIndex >= 0) ? "Save Changes" : "Add to Cart";
        addToCartBtn.setText(String.format(btnLabel + "  ·  ₱%.2f", running));
        addToCartBtn.repaint();
    }

    // ── Finalize ──────────────────────────────────────────────────
    private void finalizeMeal() {
        try {
            double total = baseItemPrice
                + (selectedSide    != null ? selectedSide.price    : 0)
                + (selectedDrink   != null ? selectedDrink.price   : 0)
                + (selectedDessert != null ? selectedDessert.price : 0);

            String summary = String.format(
                "%s Meal  (Side: %s | Drink: %s | Dessert: %s)",
                baseItemName,
                selectedSide    != null ? selectedSide.name    : "—",
                selectedDrink   != null ? selectedDrink.name   : "—",
                selectedDessert != null ? selectedDessert.name : "—"
            );

            // All IDs now captured — main item + each add-on
            CartItem newItem = new CartItem(
                summary, total, productId,
                baseItemName, baseItemPrice,
                selectedSide    != null ? selectedSide.name    : null,
                selectedSide    != null ? selectedSide.id      : -1,
                selectedDrink   != null ? selectedDrink.name   : null,
                selectedDrink   != null ? selectedDrink.id     : -1,
                selectedDessert != null ? selectedDessert.name : null,
                selectedDessert != null ? selectedDessert.id   : -1
            );

            if (editIndex >= 0 && menuOwner != null) {
                menuOwner.replaceCartItem(editIndex, newItem);
                dispose();
                new CheckoutScreen(menuOwner).setVisible(true);
            } else {
                if (menuOwner != null) menuOwner.addCartItem(newItem);
                dispose();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            dispose();
        }
    }

    // ── UI helpers ────────────────────────────────────────────────
    private JButton createOptionCard(String name, String addonStr, int step) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                boolean sel = Boolean.TRUE.equals(getClientProperty("selected"));
                g2.setColor(sel ? SELECTED_BG : CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(sel ? SELECTED_BD : BORDER_SOFT);
                g2.setStroke(new BasicStroke(sel ? 2f : 1f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 20, 20));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setName(name);
        btn.setLayout(new BorderLayout());
        String priceLabel = addonStr.equals("+0")
            ? "<font color='#888888'>Free</font>"
            : "<font color='#E8730A'>" + addonStr + "</font>";
        JLabel lbl = new JLabel(
            "<html><center><b>" + name + "</b><br>" + priceLabel + "</center></html>",
            SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btn.add(lbl);
        btn.setPreferredSize(new Dimension(140, 110));
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.putClientProperty("selected", false);
        return btn;
    }

    private JButton createSidebarBtn(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setForeground(new Color(200, 200, 200));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void highlightSidebar(int active) {
        for (int i = 0; i < sidebarBtns.length; i++) {
            boolean on = (i == active);
            sidebarBtns[i].setForeground(on ? ORANGE : new Color(200, 200, 200));
            sidebarBtns[i].setFont(new Font("SansSerif",
                on ? Font.BOLD : Font.PLAIN, on ? 13 : 12));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new MealCustomizer(null, "Chicken Inasal", 119.00, 1, null).setVisible(true));
    }
}