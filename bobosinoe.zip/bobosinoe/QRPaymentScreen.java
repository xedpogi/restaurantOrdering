package bobosinoe;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * QR Payment Screen — shown when the customer taps "Pay Here".
 *
 * Displays:
 *  - A QRPH QR code image (loaded from qrph.png in the same folder, or a placeholder)
 *  - The total amount to pay
 *  - A "Detecting payment..." animation that resolves after ~5 seconds (simulated)
 *  - On success → shows ReceiptScreen with the appropriate pickup message
 *
 * To use your real QR code: place your QR image file as:
 *   bobosinoe/qrph.png  (next to the .java files, or in the working directory)
 */
public class QRPaymentScreen extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color GREEN       = new Color(0x28, 0xA7, 0x45);
    private static final Color CARD_WHITE  = Color.WHITE;
    private static final Color BORDER_SOFT = new Color(0xE5, 0xE0, 0xD8);

    private final Menu   menuOwner;
    private final String pickupMethod;
    private final String tableNumber;
    private final double total;

    private JLabel  lblStatus;
    private JLabel  lblDots;
    private JButton btnCancel;
    private JButton btnSimulatePaid;

    private Timer  dotTimer;
    private Timer  detectTimer;
    private int    dotCount = 0;
    private boolean paid   = false;

    public QRPaymentScreen(JDialog owner, Menu menuOwner,
                           String pickupMethod, String tableNumber, double total) {
        super(owner, "Josie's Cafe – QR Payment", true);
        this.menuOwner    = menuOwner;
        this.pickupMethod = pickupMethod;
        this.tableNumber  = tableNumber;
        this.total        = total;

        setSize(480, 700);
        setLocationRelativeTo(owner);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (!paid) cancelAndReturn();
            }
        });

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // ── Header ───────────────────────────────────────────────
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(480, 80));
        header.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel lblTitle = new JLabel("Scan to Pay", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Use GCash, Maya, or any QRPH-compatible app",
                                   SwingConstants.CENTER);
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(new Color(0xFF, 0xE0, 0xC0));

        header.add(lblTitle);
        header.add(lblSub);
        root.add(header, BorderLayout.NORTH);

        // ── Center content ────────────────────────────────────────
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(BG_CREAM);
        center.setBorder(new EmptyBorder(20, 30, 20, 30));

        // Amount to pay
        JLabel lblAmountLabel = new JLabel("Amount to Pay", SwingConstants.CENTER);
        lblAmountLabel.setFont(new Font("Georgia", Font.PLAIN, 14));
        lblAmountLabel.setForeground(new Color(0x88, 0x88, 0x88));
        lblAmountLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblAmount = new JLabel(String.format("₱%.2f", total), SwingConstants.CENTER);
        lblAmount.setFont(new Font("Georgia", Font.BOLD, 38));
        lblAmount.setForeground(ORANGE);
        lblAmount.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(lblAmountLabel);
        center.add(Box.createVerticalStrut(4));
        center.add(lblAmount);
        center.add(Box.createVerticalStrut(18));

        // QR code panel
        JPanel qrPanel = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(BORDER_SOFT);
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 20, 20));
                g2.dispose();
            }
        };
        qrPanel.setOpaque(false);
        qrPanel.setMaximumSize(new Dimension(300, 300));
        qrPanel.setPreferredSize(new Dimension(300, 300));
        qrPanel.setBorder(new EmptyBorder(16, 16, 16, 16));
        qrPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Try to load qrph.png; fall back to generated placeholder
        JLabel qrLabel = loadQRLabel();
        qrPanel.add(qrLabel, BorderLayout.CENTER);

        center.add(qrPanel);
        center.add(Box.createVerticalStrut(18));

        // QRPH badge
        JLabel qrBadge = new JLabel("⚡  QRPH  |  InstaPay  |  PESONet", SwingConstants.CENTER);
        qrBadge.setFont(new Font("SansSerif", Font.BOLD, 12));
        qrBadge.setForeground(new Color(0x00, 0x6B, 0xD6));
        qrBadge.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(qrBadge);
        center.add(Box.createVerticalStrut(18));

        // Status row
        lblStatus = new JLabel("Waiting for payment...", SwingConstants.CENTER);
        lblStatus.setFont(new Font("Georgia", Font.ITALIC, 14));
        lblStatus.setForeground(DARK);
        lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblDots = new JLabel("●  ○  ○", SwingConstants.CENTER);
        lblDots.setFont(new Font("SansSerif", Font.PLAIN, 20));
        lblDots.setForeground(ORANGE);
        lblDots.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(lblStatus);
        center.add(Box.createVerticalStrut(6));
        center.add(lblDots);
        center.add(Box.createVerticalStrut(18));

        // Simulate payment button (for demo — label it clearly)
        btnSimulatePaid = makeRoundedBtn(
            "✓  Payment Received (Demo)", GREEN, new Color(0x1E, 0x88, 0x36));
        btnSimulatePaid.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnSimulatePaid.setMaximumSize(new Dimension(340, 52));
        btnSimulatePaid.addActionListener(e -> onPaymentDetected());
        center.add(btnSimulatePaid);
        center.add(Box.createVerticalStrut(10));

        // Cancel button
        btnCancel = makeRoundedBtn("✕  Cancel Payment", DARK, new Color(0x3A, 0x3A, 0x3C));
        btnCancel.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCancel.setMaximumSize(new Dimension(340, 48));
        btnCancel.addActionListener(e -> cancelAndReturn());
        center.add(btnCancel);

        JScrollPane scroll = new JScrollPane(center);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        root.add(scroll, BorderLayout.CENTER);

        // ── Start dot animation ───────────────────────────────────
        startDotAnimation();
    }

    // ── Load QR image or draw placeholder ────────────────────────
    private JLabel loadQRLabel() {
        // Try several common paths for the QR image
        String[] paths = {
            "bobosinoe/qrph.png",
            "qrph.png",
            "src/bobosinoe/qrph.png",
            "resources/qrph.png"
        };

        for (String path : paths) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    BufferedImage img = ImageIO.read(f);
                    if (img != null) {
                        Image scaled = img.getScaledInstance(260, 260, Image.SCALE_SMOOTH);
                        return new JLabel(new ImageIcon(scaled), SwingConstants.CENTER);
                    }
                }
            } catch (Exception ignored) {}
        }

        // Fallback: draw a QR-like placeholder with instructions
        BufferedImage placeholder = new BufferedImage(260, 260, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = placeholder.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 260, 260);

        // Draw QR corner squares (decorative)
        g.setColor(DARK);
        drawQRCorner(g, 10, 10);
        drawQRCorner(g, 190, 10);
        drawQRCorner(g, 10, 190);

        // Center message
        g.setColor(new Color(0x88, 0x88, 0x88));
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        FontMetrics fm = g.getFontMetrics();

        String[] lines = {"Place your", "QRPH image", "here as:", "qrph.png"};
        int y = 100;
        for (String line : lines) {
            int x = (260 - fm.stringWidth(line)) / 2;
            g.drawString(line, x, y);
            y += 22;
        }
        g.setColor(ORANGE);
        g.setFont(new Font("SansSerif", Font.BOLD, 11));
        String sub = "(in project folder)";
        g.drawString(sub, (260 - fm.stringWidth(sub)) / 2, y + 5);

        g.dispose();
        return new JLabel(new ImageIcon(placeholder), SwingConstants.CENTER);
    }

    private void drawQRCorner(Graphics2D g, int x, int y) {
        g.setColor(DARK);
        g.fillRect(x, y, 55, 55);
        g.setColor(Color.WHITE);
        g.fillRect(x + 8, y + 8, 39, 39);
        g.setColor(DARK);
        g.fillRect(x + 14, y + 14, 27, 27);
    }

    // ── Dot animation ─────────────────────────────────────────────
    private void startDotAnimation() {
        String[] frames = {"●  ○  ○", "○  ●  ○", "○  ○  ●", "○  ●  ○"};
        dotTimer = new Timer(500, e -> {
            dotCount = (dotCount + 1) % frames.length;
            lblDots.setText(frames[dotCount]);
        });
        dotTimer.start();
    }

    // ── Called when payment is confirmed ─────────────────────────
    private void onPaymentDetected() {
        if (paid) return;
        paid = true;

        if (dotTimer != null) dotTimer.stop();

        lblStatus.setText("✓ Payment Confirmed!");
        lblStatus.setForeground(GREEN);
        lblDots.setText("●  ●  ●");
        lblDots.setForeground(GREEN);
        btnSimulatePaid.setEnabled(false);
        btnCancel.setEnabled(false);

        // Small delay then open receipt
        Timer t = new Timer(800, e -> {
            for (Window w : Window.getWindows()) {
                w.dispose();
            }
            new ReceiptScreen(menuOwner, pickupMethod, tableNumber, "QR_PAY").setVisible(true);
        });;
        t.setRepeats(false);
        t.start();
    }

    // ── Cancel ────────────────────────────────────────────────────
    private void cancelAndReturn() {
        if (dotTimer  != null) dotTimer.stop();
        if (detectTimer != null) detectTimer.stop();
        dispose();
    }

    // ── Button helper ─────────────────────────────────────────────
    private JButton makeRoundedBtn(String text, Color base, Color hover) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isEnabled()
                    ? (getModel().isRollover() ? hover : base)
                    : new Color(0xCC, 0xCC, 0xCC));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 28, 28);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.repaint(); }
        });
        return btn;
    }
}