package bobosinoe;

/**
 * Represents a single item in the customer's cart.
 * isMeal = true  → was customized; can be re-edited via MealCustomizer
 * isMeal = false → Ala Carte; no re-edit flow
 */
public class CartItem {
    public String  description;
    public double  price;
    public boolean isMeal;
    public int     productId;     // FK → products.productId (main item)

    // Meal sub-fields (used to re-open MealCustomizer with pre-filled state)
    public String baseItemName;
    public double baseItemPrice;
    public String selectedSide;
    public String selectedDrink;
    public String selectedDessert;

    // ── NEW: IDs for each add-on ──────────────────────────────────
    public int sideId;     // FK → products.productId  (-1 = none)
    public int drinkId;    // FK → products.productId  (-1 = none)
    public int dessertId;  // FK → products.productId  (-1 = none)

    /** Ala Carte constructor — no add-ons */
    public CartItem(String description, double price, int productId) {
        this.description = description;
        this.price       = price;
        this.isMeal      = false;
        this.productId   = productId;
        this.sideId      = -1;
        this.drinkId     = -1;
        this.dessertId   = -1;
    }

    /** Meal constructor — includes add-on names AND IDs */
    public CartItem(String description, double price, int productId,
                    String baseItemName, double baseItemPrice,
                    String side,   int sideId,
                    String drink,  int drinkId,
                    String dessert,int dessertId) {
        this.description     = description;
        this.price           = price;
        this.isMeal          = true;
        this.productId       = productId;
        this.baseItemName    = baseItemName;
        this.baseItemPrice   = baseItemPrice;
        this.selectedSide    = side;
        this.selectedDrink   = drink;
        this.selectedDessert = dessert;
        this.sideId          = sideId;
        this.drinkId         = drinkId;
        this.dessertId       = dessertId;
    }
}