package bobosinoe;

import java.awt.EventQueue;
import java.awt.*;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;

public class OrderManagingInterface extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	private static java.net.ServerSocket lock;

	public static void main(String[] args) {
	    try {
	        lock = new java.net.ServerSocket(9871);  // port 9871 = kiosk lock
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(null,
	            "The Admin panel is already running.\nClose it first before opening the Kiosk.",
	            "System Already Running", JOptionPane.ERROR_MESSAGE);
	        System.exit(0);
	    }
	    EventQueue.invokeLater(new Runnable() {
	        public void run() {
	            try {
	                OrderManagingInterface frame = new OrderManagingInterface();
	                frame.setVisible(true);
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	    });
	}

	/**
	 * Create the frame.
	 */
	public OrderManagingInterface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 384, 508);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.setBackground(new Color(0xFF, 0xF8, 0xF0));
		
		JLabel lblWelcome = new JLabel("WELCOME TO");
		lblWelcome.setFont(new Font("Georgia", Font.BOLD, 28));
		lblWelcome.setForeground(new Color(0x1C, 0x1C, 0x1E));
		lblWelcome.setBounds(78, 10, 266, 41);
		contentPane.add(lblWelcome);
		
		JLabel lblCafe = new JLabel("JOSIE'S CAFE!");
		lblCafe.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 42));
		lblCafe.setForeground(new Color(0xE8, 0x73, 0x0A));
		lblCafe.setBounds(20, 53, 350, 47);
		contentPane.add(lblCafe);
		
		JButton tapBtn = new JButton("TAP TO ORDER") {
		    @Override
		    protected void paintComponent(Graphics g) {
		        Graphics2D g2 = (Graphics2D) g.create();
		        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		        g2.setColor(new Color(0xE8, 0x73, 0x0A));
		        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 40, 40);
		        g2.dispose();
		        super.paintComponent(g);
		    }
		};
		tapBtn.setContentAreaFilled(false);
		tapBtn.setBorderPainted(false);
		tapBtn.setForeground(Color.WHITE);
		tapBtn.setFont(new Font("Arial", Font.BOLD, 22));
		tapBtn.setBounds(30, 340, 310, 55);
		contentPane.add(tapBtn);
		
		tapBtn.addActionListener(e -> {
		    new DineOrOut().setVisible(true); 
		    dispose();                         
		});
	}
}
