package bobosinoe;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * Payment method screen — shown after pickup method is decided.
 *
 * "Pay Here (QR)"  → opens QRPaymentScreen (QRPH QR code + simulated detection)
 * "Pay at Counter" → opens ReceiptScreen directly with COUNTER payment type
 */
public class PaymentMethodScreen extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color DARK_HOVER  = new Color(0x3A, 0x3A, 0x3C);
    private static final Color CARD_WHITE  = Color.WHITE;
    private static final Color BORDER_SOFT = new Color(0xE5, 0xE0, 0xD8);
    private static final Color GREEN       = new Color(0x28, 0xA7, 0x45);
    private static final Color GREEN_HOVER = new Color(0x1E, 0x88, 0x36);

    private final Menu   menuOwner;
    private final String pickupMethod;
    private final String tableNumber;

    public PaymentMethodScreen(JDialog owner, Menu menuOwner,
                               String pickupMethod, String tableNumber) {
        super(owner, "Josie's Cafe – Payment", true);
        this.menuOwner    = menuOwner;
        this.pickupMethod = pickupMethod;
        this.tableNumber  = tableNumber;

        setSize(480, 700);
        setLocationRelativeTo(owner);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // ── Header ───────────────────────────────────────────────
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(480, 80));
        header.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel lblTitle = new JLabel("JOSIE'S CAFE  —  Payment", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20));
        lblTitle.setForeground(Color.WHITE);

        String pickupLine = pickupMethod.equals("TABLE")
            ? "🪑  Serving at Table " + tableNumber
            : "🏪  Pick up at Counter";
        JLabel lblPickup = new JLabel(pickupLine, SwingConstants.CENTER);
        lblPickup.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblPickup.setForeground(new Color(0xFF, 0xE0, 0xC0));

        header.add(lblTitle);
        header.add(lblPickup);
        root.add(header, BorderLayout.NORTH);

        // ── Scrollable body ───────────────────────────────────────
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(BG_CREAM);
        body.setBorder(new EmptyBorder(16, 20, 16, 20));

        List<CartItem> items = menuOwner.getCartItems();
        double total = 0;

        // Summary heading
        JLabel lblSummaryHead = new JLabel("ORDER SUMMARY");
        lblSummaryHead.setFont(new Font("Georgia", Font.BOLD, 14));
        lblSummaryHead.setForeground(DARK);
        lblSummaryHead.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(lblSummaryHead);
        body.add(Box.createVerticalStrut(8));
        body.add(makeDivider());
        body.add(Box.createVerticalStrut(10));

        for (CartItem item : items) {
            total += item.price;
            body.add(buildSummaryRow(item));
            body.add(Box.createVerticalStrut(8));
        }

        body.add(makeDivider());
        body.add(Box.createVerticalStrut(10));

        // Total row
        JPanel totalRow = new JPanel(new BorderLayout());
        totalRow.setOpaque(false);
        totalRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        totalRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblTotalText = new JLabel("TOTAL");
        lblTotalText.setFont(new Font("Georgia", Font.BOLD, 16));
        JLabel lblTotalAmt = new JLabel(String.format("₱%.2f", total), SwingConstants.RIGHT);
        lblTotalAmt.setFont(new Font("Georgia", Font.BOLD, 18));
        lblTotalAmt.setForeground(ORANGE);
        totalRow.add(lblTotalText, BorderLayout.WEST);
        totalRow.add(lblTotalAmt,  BorderLayout.EAST);
        body.add(totalRow);
        body.add(Box.createVerticalStrut(18));

        body.add(makeDivider());
        body.add(Box.createVerticalStrut(18));

        // ── Payment heading ───────────────────────────────────────
        JLabel lblPayHead = new JLabel("HOW WOULD YOU LIKE TO PAY?");
        lblPayHead.setFont(new Font("Georgia", Font.BOLD, 14));
        lblPayHead.setForeground(DARK);
        lblPayHead.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(lblPayHead);
        body.add(Box.createVerticalStrut(14));

        // ── Pay Here (QR) card ────────────────────────────────────
        final double finalTotal = total;
        JPanel payHereCard = buildPayCard(
            "📱  Pay Here (QR / e-Wallet)",
            "GCash, Maya, or any QRPH-compatible app",
            GREEN, GREEN_HOVER,
            e -> handlePayHere(finalTotal)
        );
        payHereCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(payHereCard);
        body.add(Box.createVerticalStrut(12));

        // ── Pay at Counter card ───────────────────────────────────
        JPanel payCounterCard = buildPayCard(
            "💵  Pay at Counter",
            "Cash or card — pay when you collect",
            DARK, DARK_HOVER,
            e -> handlePayAtCounter()
        );
        payCounterCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(payCounterCard);
        body.add(Box.createVerticalStrut(8));

        // Hint
        JLabel hint = new JLabel(
            "<html><center><i>Choose how you'd like to pay. Your order will be prepared after confirmation.</i></center></html>",
            SwingConstants.CENTER);
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        hint.setForeground(new Color(0xAA, 0xAA, 0xAA));
        hint.setAlignmentX(Component.CENTER_ALIGNMENT);
        body.add(hint);

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        root.add(scroll, BorderLayout.CENTER);
    }

    // ── Summary item row ──────────────────────────────────────────
    private JPanel buildSummaryRow(CartItem item) {
        JPanel row = new JPanel(new BorderLayout(10, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14));
                g2.setColor(BORDER_SOFT);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 14, 14));
                g2.dispose();
            }
        };
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(10, 14, 10, 14));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        String desc = item.description;
        String displayHtml;
        if (desc.contains("(") && desc.contains(")")) {
            int paren  = desc.indexOf("(");
            String main   = desc.substring(0, paren).trim();
            String detail = desc.substring(paren);
            displayHtml = "<html><body style='width:250px'><b>" + main + "</b><br>"
                + "<span style='color:#888888;font-size:10px'>" + detail + "</span></body></html>";
        } else {
            displayHtml = "<html><body style='width:250px'><b>" + desc + "</b></body></html>";
        }

        JLabel lblDesc = new JLabel(displayHtml);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JLabel lblPrice = new JLabel(String.format("₱%.2f", item.price));
        lblPrice.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblPrice.setForeground(ORANGE);
        lblPrice.setHorizontalAlignment(SwingConstants.RIGHT);
        lblPrice.setPreferredSize(new Dimension(70, 30));
        lblPrice.setVerticalAlignment(SwingConstants.TOP);

        row.add(lblDesc,  BorderLayout.CENTER);
        row.add(lblPrice, BorderLayout.EAST);
        return row;
    }

    // ── Payment option card ───────────────────────────────────────
    private JPanel buildPayCard(String title, String subtitle,
                                Color base, Color hover,
                                ActionListener action) {
        JPanel card = new JPanel(new BorderLayout(14, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(base);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(18, 20, 18, 20));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel textCol = new JPanel(new GridLayout(2, 1, 0, 3));
        textCol.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Georgia", Font.BOLD, 15));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(new Font("SansSerif", Font.ITALIC, 11));
        lblSub.setForeground(new Color(0xFF, 0xFF, 0xFF, 180));

        textCol.add(lblTitle);
        textCol.add(lblSub);
        card.add(textCol, BorderLayout.CENTER);

        JLabel arrow = new JLabel("›");
        arrow.setFont(new Font("SansSerif", Font.BOLD, 28));
        arrow.setForeground(Color.WHITE);
        card.add(arrow, BorderLayout.EAST);

        // Click handling on card and all children
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                action.actionPerformed(new ActionEvent(card,
                    ActionEvent.ACTION_PERFORMED, "click"));
            }
            @Override public void mouseEntered(MouseEvent e) {
                card.setBackground(hover); card.repaint();
            }
            @Override public void mouseExited(MouseEvent e) {
                card.setBackground(base); card.repaint();
            }
        };
        card.addMouseListener(ma);
        for (Component c : card.getComponents()) c.addMouseListener(ma);
        for (Component c : textCol.getComponents()) c.addMouseListener(ma);

        return card;
    }

    // ── Handlers ──────────────────────────────────────────────────

    private void handlePayAtCounter() {
        saveOrderToDatabase("COUNTER");
        // Close every window except the receipt we're about to open
        for (Window w : Window.getWindows()) {
            w.dispose();
        }
        new ReceiptScreen(menuOwner, pickupMethod, tableNumber, "COUNTER").setVisible(true);
    }

    private void handlePayHere(double total) {
        saveOrderToDatabase("QR_PAY");
        // Close every window — QRPaymentScreen will open ReceiptScreen itself
        for (Window w : Window.getWindows()) {
            w.dispose();
        }
        new QRPaymentScreen(null, menuOwner, pickupMethod, tableNumber, total).setVisible(true);
    }
    // ── Helper ────────────────────────────────────────────────────
    private JSeparator makeDivider() {
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_SOFT);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        return sep;
    }

    private void saveOrderToDatabase(String paymentMethod) {
        List<CartItem> items = menuOwner.getCartItems();
        double total = 0;
        for (CartItem item : items) total += item.price;

        String customerLabel = pickupMethod.equals("TABLE") ? "Table " + tableNumber : "Counter";

        try (java.sql.Connection conn = DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(
                 "INSERT INTO orders (customerName, total, orderStatus, orderDate, paymentMethod) VALUES (?,?,'pending',NOW(),?)",
                 java.sql.Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, customerLabel);
            ps.setDouble(2, total);
            ps.setString(3, paymentMethod);
            ps.executeUpdate();

            java.sql.ResultSet keys = ps.getGeneratedKeys();
            int orderId = -1;
            if (keys.next()) orderId = keys.getInt(1);

            try (java.sql.PreparedStatement itemPs = conn.prepareStatement(
                    "INSERT INTO ordered_items (orderId, productId, sideId, drinkId, dessertId, quantity, price) VALUES (?,?,?,?,?,?,?)")) {
                for (CartItem item : items) {
                    itemPs.setInt(1, orderId);
                    itemPs.setInt(2, item.productId);
                    itemPs.setInt(3, item.sideId);     // -1 if ala carte
                    itemPs.setInt(4, item.drinkId);    // -1 if ala carte
                    itemPs.setInt(5, item.dessertId);  // -1 if ala carte
                    itemPs.setInt(6, 1);
                    itemPs.setDouble(7, item.price);
                    itemPs.addBatch();
                }
                itemPs.executeBatch();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}