package bobosinoe;

/**
 * Represents a single item in the customer's cart.
 * isMeal = true  → was customized; can be re-edited via MealCustomizer
 * isMeal = false → Ala Carte; no re-edit flow
 */
public class CartItem {
    public String  description;   // full display string
    public double  price;
    public boolean isMeal;

    // Meal sub-fields (used to re-open MealCustomizer with pre-filled state)
    public String baseItemName;   // e.g. "Chicken Inasal"
    public double baseItemPrice;
    public String selectedSide;
    public String selectedDrink;
    public String selectedDessert;

    /** Ala Carte constructor */
    public CartItem(String description, double price) {
        this.description   = description;
        this.price         = price;
        this.isMeal        = false;
    }

    /** Meal constructor */
    public CartItem(String description, double price,
                    String baseItemName, double baseItemPrice,
                    String side, String drink, String dessert) {
        this.description    = description;
        this.price          = price;
        this.isMeal         = true;
        this.baseItemName   = baseItemName;
        this.baseItemPrice  = baseItemPrice;
        this.selectedSide   = side;
        this.selectedDrink  = drink;
        this.selectedDessert = dessert;
    }
}