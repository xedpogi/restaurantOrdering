package bobosinoe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Modal dialog that appears after clicking a menu item.
 * Asks the customer: Ala Carte only, or Make it a Meal?
 */
public class MealTypeDialog extends JDialog {

    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color DARK_HOVER  = new Color(0x3A, 0x3A, 0x3C);
    private static final Color WHITE       = Color.WHITE;

    /** Result: true = Make it a Meal, false = Ala Carte, null = dialog closed */
    private Boolean result = null;

    /**
     * @param owner   The parent JFrame (Menu screen)
     * @param itemName  e.g. "Chicken Inasal"
     * @param itemPrice e.g. "119.00"
     */
    public MealTypeDialog(JFrame owner, String itemName, String itemPrice) {
        super(owner, "How would you like your order?", true); // modal
        setSize(420, 320);
        setLocationRelativeTo(owner);
        setResizable(false);
        setUndecorated(false);

        JPanel content = new JPanel(null);
        content.setBackground(BG_CREAM);
        setContentPane(content);

        // Orange top stripe
        JPanel topBar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(ORANGE);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        topBar.setOpaque(false);
        topBar.setBounds(0, 0, 420, 6);
        content.add(topBar);

        // Item name label
        JLabel lblItem = new JLabel(itemName, SwingConstants.CENTER);
        lblItem.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 20));
        lblItem.setForeground(ORANGE);
        lblItem.setBounds(0, 25, 420, 30);
        content.add(lblItem);

        // Price label
        JLabel lblPrice = new JLabel("₱" + itemPrice, SwingConstants.CENTER);
        lblPrice.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblPrice.setForeground(new Color(0x88, 0x88, 0x88));
        lblPrice.setBounds(0, 58, 420, 22);
        content.add(lblPrice);

        // Question
        JLabel lblQ = new JLabel("Would you like to make this a meal?", SwingConstants.CENTER);
        lblQ.setFont(new Font("Georgia", Font.PLAIN, 15));
        lblQ.setForeground(DARK);
        lblQ.setBounds(0, 90, 420, 28);
        content.add(lblQ);

        JSeparator sep = new JSeparator();
        sep.setBounds(40, 125, 340, 2);
        sep.setForeground(new Color(0xE0, 0xD5, 0xC5));
        content.add(sep);

        // ── Ala Carte button ──
        JButton btnAlaCarte = makeRoundedBtn(
            "<html><center><b>No, Ala Carte Only</b><br>"
            + "<span style='font-size:10px'>Just this item</span></center></html>",
            DARK, DARK_HOVER
        );
        btnAlaCarte.setBounds(30, 145, 165, 90);
        content.add(btnAlaCarte);
        btnAlaCarte.addActionListener(e -> {
            result = false;
            dispose();
        });

        // ── Make it a Meal button ──
        JButton btnMeal = makeRoundedBtn(
            "<html><center><b>Yes, Make it a Meal</b><br>"
            + "<span style='font-size:10px'>Add sides, drink & more</span></center></html>",
            ORANGE, ORANGE_DARK
        );
        btnMeal.setBounds(220, 145, 165, 90);
        content.add(btnMeal);
        btnMeal.addActionListener(e -> {
            result = true;
            dispose();
        });

        // Footer hint
        JLabel lblHint = new JLabel("Meal add-ons are priced separately", SwingConstants.CENTER);
        lblHint.setFont(new Font("Arial", Font.ITALIC, 11));
        lblHint.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblHint.setBounds(0, 250, 420, 20);
        content.add(lblHint);
    }

    /** Shows the dialog and returns the user's choice. */
    public Boolean getResult() {
        setVisible(true); // blocks until disposed
        return result;
    }

    // ── Helper ─────────────────────────────────────────────────────
    private JButton makeRoundedBtn(String html, Color base, Color hover) {
        JButton btn = new JButton(html) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : base);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.repaint(); }
            public void mouseExited(java.awt.event.MouseEvent e)  { btn.repaint(); }
        });
        return btn;
    }
}