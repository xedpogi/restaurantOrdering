package bobosinoe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;
import javax.swing.border.EmptyBorder;

/**
 * Receipt-style checkout screen.
 * Lists all cart items with Edit and Delete buttons per row.
 * Edit (meal items only) → opens MealCustomizer → comes back here.
 * Delete → removes item from cart and refreshes this screen.
 * Checkout button at the bottom.
 */
public class CheckoutScreen extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color CARD_WHITE  = Color.WHITE;
    private static final Color BORDER_SOFT = new Color(0xE5, 0xE0, 0xD8);
    private static final Color RED_SOFT    = new Color(0xD0, 0x2E, 0x2E);
    private static final Color RED_HOVER   = new Color(0xA8, 0x20, 0x20);

    private final Menu menuOwner;
    private JPanel     receiptPanel;
    private JButton    checkoutBtn;

    public CheckoutScreen(Menu menuOwner) {
        super(menuOwner, "Josie's Cafe – Your Order", true);
        this.menuOwner = menuOwner;

        setSize(500, 680);
        setLocationRelativeTo(menuOwner);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // ── Header ───────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(500, 70));

        JLabel lblTitle = new JLabel("JOSIE'S CAFE  —  Your Order", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20));
        lblTitle.setForeground(Color.WHITE);
        header.add(lblTitle, BorderLayout.CENTER);
        root.add(header, BorderLayout.NORTH);

        // ── Scrollable receipt area ───────────────────────────────
        receiptPanel = new JPanel();
        receiptPanel.setLayout(new BoxLayout(receiptPanel, BoxLayout.Y_AXIS));
        receiptPanel.setBackground(BG_CREAM);
        receiptPanel.setBorder(new EmptyBorder(16, 20, 16, 20));

        JScrollPane scroll = new JScrollPane(receiptPanel);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        root.add(scroll, BorderLayout.CENTER);

        // ── Checkout button ───────────────────────────────────────
        checkoutBtn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ORANGE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        checkoutBtn.setContentAreaFilled(false);
        checkoutBtn.setBorderPainted(false);
        checkoutBtn.setFocusPainted(false);
        checkoutBtn.setForeground(Color.WHITE);
        checkoutBtn.setFont(new Font("SansSerif", Font.BOLD, 17));
        checkoutBtn.setPreferredSize(new Dimension(0, 65));
        checkoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        checkoutBtn.addActionListener(e -> handleCheckout());
        root.add(checkoutBtn, BorderLayout.SOUTH);

        buildReceipt();
    }

    // ── Build / rebuild receipt list ─────────────────────────────
    public void buildReceipt() {
        receiptPanel.removeAll();
        List<CartItem> items = menuOwner.getCartItems();

        if (items.isEmpty()) {
            JLabel empty = new JLabel("Your cart is empty.", SwingConstants.CENTER);
            empty.setFont(new Font("Georgia", Font.ITALIC, 15));
            empty.setForeground(new Color(0xAA, 0xAA, 0xAA));
            empty.setAlignmentX(Component.CENTER_ALIGNMENT);
            receiptPanel.add(Box.createVerticalStrut(40));
            receiptPanel.add(empty);
            checkoutBtn.setText("Checkout  ·  ₱0.00");
            receiptPanel.revalidate();
            receiptPanel.repaint();
            return;
        }

        // Receipt header row
        receiptPanel.add(receiptHeaderRow());
        receiptPanel.add(Box.createVerticalStrut(6));
        receiptPanel.add(makeDivider());
        receiptPanel.add(Box.createVerticalStrut(10));

        double total = 0;
        for (int i = 0; i < items.size(); i++) {
            CartItem item = items.get(i);
            total += item.price;
            receiptPanel.add(buildItemRow(item, i));
            receiptPanel.add(Box.createVerticalStrut(10));
        }

        receiptPanel.add(makeDivider());
        receiptPanel.add(Box.createVerticalStrut(10));
        receiptPanel.add(buildTotalRow(total));
        receiptPanel.add(Box.createVerticalStrut(6));
        receiptPanel.add(buildFooterNote());

        checkoutBtn.setText(String.format("Checkout  ·  ₱%.2f", total));
        receiptPanel.revalidate();
        receiptPanel.repaint();
    }

    // ── Receipt header ────────────────────────────────────────────
    private JPanel receiptHeaderRow() {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JLabel lblOrder = new JLabel("ORDER SUMMARY");
        lblOrder.setFont(new Font("Georgia", Font.BOLD, 14));
        lblOrder.setForeground(DARK);

        JLabel lblDate = new JLabel(java.time.LocalDate.now().toString(), SwingConstants.RIGHT);
        lblDate.setFont(new Font("SansSerif", Font.ITALIC, 12));
        lblDate.setForeground(new Color(0xAA, 0xAA, 0xAA));

        row.add(lblOrder, BorderLayout.WEST);
        row.add(lblDate, BorderLayout.EAST);
        return row;
    }

    // ── Item row: description + price + Edit/Delete buttons ───────
    private JPanel buildItemRow(CartItem item, int index) {
        // Outer card
        JPanel card = new JPanel(new BorderLayout(10, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_SOFT);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 16, 16));
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(12, 14, 12, 14));
        // No fixed max height — let the card grow to fit wrapped text

        // Left: index badge + description
        JPanel leftSide = new JPanel(new BorderLayout(10, 0));
        leftSide.setOpaque(false);

        JLabel badge = new JLabel(String.valueOf(index + 1));
        badge.setFont(new Font("Georgia", Font.BOLD, 14));
        badge.setForeground(ORANGE);
        badge.setPreferredSize(new Dimension(22, 22));
        badge.setHorizontalAlignment(SwingConstants.CENTER);

        // Format description nicely — split meal details onto second line
        String desc = item.description;
        String displayHtml;
        if (desc.contains("(") && desc.contains(")")) {
            int paren = desc.indexOf("(");
            String mainLine   = desc.substring(0, paren).trim();
            String detailLine = desc.substring(paren);
            displayHtml = "<html><body style='width:200px'><b>" + mainLine + "</b><br>"
                + "<span style='color:#888888; font-size:10px'>" + detailLine + "</span></body></html>";
        } else {
            displayHtml = "<html><body style='width:200px'><b>" + desc + "</b></body></html>";
        }
        JLabel lblDesc = new JLabel(displayHtml);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 13));

        leftSide.add(badge, BorderLayout.WEST);
        leftSide.add(lblDesc, BorderLayout.CENTER);
        card.add(leftSide, BorderLayout.CENTER);

        // Right: price + action buttons
        JPanel rightSide = new JPanel();
        rightSide.setLayout(new BoxLayout(rightSide, BoxLayout.Y_AXIS));
        rightSide.setOpaque(false);

        JLabel lblPrice = new JLabel(String.format("₱%.2f", item.price), SwingConstants.RIGHT);
        lblPrice.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblPrice.setForeground(ORANGE);
        lblPrice.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btnRow.setOpaque(false);

        // Edit button — only for meal items
        if (item.isMeal) {
            JButton editBtn = makeSmallBtn("✏ Edit", DARK, new Color(0x3A, 0x3A, 0x3C));
            editBtn.addActionListener(e -> {
                dispose(); // close checkout
                new MealCustomizer(menuOwner, item, index, this).setVisible(true);
            });
            btnRow.add(editBtn);
        }

        // Delete button
        JButton delBtn = makeSmallBtn("✕ Remove", RED_SOFT, RED_HOVER);
        delBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Remove \"" + item.description.split("\\(")[0].trim() + "\" from your order?",
                "Remove Item", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                menuOwner.removeCartItem(index);
                buildReceipt();
            }
        });
        btnRow.add(delBtn);

        rightSide.add(lblPrice);
        rightSide.add(Box.createVerticalStrut(6));
        rightSide.add(btnRow);

        card.add(rightSide, BorderLayout.EAST);
        return card;
    }

    // ── Total row ─────────────────────────────────────────────────
    private JPanel buildTotalRow(double total) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        JLabel lblTotal = new JLabel("TOTAL");
        lblTotal.setFont(new Font("Georgia", Font.BOLD, 16));
        lblTotal.setForeground(DARK);

        JLabel lblAmount = new JLabel(String.format("₱%.2f", total), SwingConstants.RIGHT);
        lblAmount.setFont(new Font("Georgia", Font.BOLD, 18));
        lblAmount.setForeground(ORANGE);

        row.add(lblTotal,  BorderLayout.WEST);
        row.add(lblAmount, BorderLayout.EAST);
        return row;
    }

    // ── Footer note ───────────────────────────────────────────────
    private JLabel buildFooterNote() {
        JLabel lbl = new JLabel("Prices include VAT. Thank you for dining with us!",
                                SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.ITALIC, 11));
        lbl.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        return lbl;
    }

    private JSeparator makeDivider() {
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_SOFT);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        return sep;
    }

    // ── Checkout handler ──────────────────────────────────────────
    private void handleCheckout() {
        List<CartItem> items = menuOwner.getCartItems();
        if (items.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Nothing to checkout!", "Empty Cart",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Step 1: Ask counter or table?
        PickupMethodDialog pickupDialog = new PickupMethodDialog(this);
        String pickup = pickupDialog.getResult();
        if (pickup == null) return;

        // Step 2: If table, ask for table number
        String tableNumber = null;
        if (pickup.equals("TABLE")) {
            TableNumberDialog tableDialog = new TableNumberDialog(this);
            tableNumber = tableDialog.getResult();
            if (tableNumber == null) return;
        }

        // Step 3: Open payment method screen
        new PaymentMethodScreen(this, menuOwner, pickup, tableNumber).setVisible(true);
    }

    @SuppressWarnings("unused")
    private void handleCheckout_UNUSED() {
        List<CartItem> items = menuOwner.getCartItems();
        // Build summary for confirmation dialog
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body style='width:280px'>");
        sb.append("<b>Order confirmed! 🎉</b><br><br>");
        double total = 0;
        for (CartItem ci : items) {
            sb.append("• ").append(ci.description).append("<br>");
            total += ci.price;
        }
        sb.append(String.format("<br><b>Total: ₱%.2f</b>", total));
        sb.append("<br><br><i>Please proceed to the counter for payment.</i>");
        sb.append("</body></html>");

        JOptionPane.showMessageDialog(this, sb.toString(),
            "Order Placed", JOptionPane.PLAIN_MESSAGE);

        // Clear cart and go back to start
        menuOwner.getCartItems().clear();
        dispose();
        menuOwner.dispose();
        new OrderManagingInterface().setVisible(true);
    }

    // ── Small pill button helper ──────────────────────────────────
    private JButton makeSmallBtn(String text, Color base, Color hover) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : base);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 11));
        btn.setPreferredSize(new Dimension(82, 26));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.repaint(); }
        });
        return btn;
    }
}