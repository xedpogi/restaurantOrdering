package bobosinoe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DineOrOut extends JFrame {

    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color WHITE       = Color.WHITE;
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK_HOVER  = new Color(0x3A, 0x3A, 0x3C);

    public DineOrOut() {
        setTitle("Josie's Cafe - How will you dine?");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 600);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(BG_CREAM);
        setContentPane(contentPane);


        JLabel lblCafeName = new JLabel("JOSIE'S CAFE", SwingConstants.CENTER);
        lblCafeName.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 20));
        lblCafeName.setForeground(ORANGE);
        lblCafeName.setBounds(0, 20, 480, 30);
        contentPane.add(lblCafeName);

     
        JSeparator separator = new JSeparator();
        separator.setBounds(40, 55, 400, 2);
        separator.setForeground(new Color(0xE0, 0xD5, 0xC5));
        contentPane.add(separator);

     
        JLabel lblTitle = new JLabel("How will you dine today?", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Georgia", Font.BOLD, 22));
        lblTitle.setForeground(DARK);
        lblTitle.setBounds(0, 70, 480, 40);
        contentPane.add(lblTitle);


        JLabel lblSub = new JLabel("Please select your dining preference", SwingConstants.CENTER);
        lblSub.setFont(new Font("Arial", Font.ITALIC, 13));
        lblSub.setForeground(new Color(0x88, 0x88, 0x88));
        lblSub.setBounds(0, 112, 480, 25);
        contentPane.add(lblSub);


        JButton btnDineIn = makeChoiceButton(
            "<html><center><span style='font-size:28px'>🍽️</span><br><br>"
            + "<b style='font-size:16px'>Dine-In</b><br>"
            + "<span style='font-size:11px; color:#cccccc'>Eat here with us</span></center></html>",
            ORANGE, ORANGE_DARK
        );
        btnDineIn.setBounds(50, 170, 170, 200);
        contentPane.add(btnDineIn);
		btnDineIn.addActionListener(e -> {
		    new Menu().setVisible(true); 
		    dispose();                         
		});

        
        JButton btnTakeOut = makeChoiceButton(
            "<html><center><span style='font-size:28px'>🥡</span><br><br>"
            + "<b style='font-size:16px'>Take-Out</b><br>"
            + "<span style='font-size:11px; color:#cccccc'>Order to go</span></center></html>",
            DARK, DARK_HOVER
        );
        btnTakeOut.setBounds(260, 170, 170, 200);
        contentPane.add(btnTakeOut);
		btnTakeOut.addActionListener(e -> {
		    new Menu().setVisible(true); 
		    dispose();                         
		});

        
        JLabel lblFooter = new JLabel("Tap a button to continue", SwingConstants.CENTER);
        lblFooter.setFont(new Font("Arial", Font.PLAIN, 12));
        lblFooter.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblFooter.setBounds(0, 420, 480, 25);
        contentPane.add(lblFooter);


        JPanel bottomBar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(ORANGE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        bottomBar.setBounds(0, 560, 480, 6);
        bottomBar.setOpaque(false);
        contentPane.add(bottomBar);

        setVisible(true);
    }

    // ── Helper: rounded choice button ─────────────────────────────
    private JButton makeChoiceButton(String text, Color baseColor, Color hoverColor) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hoverColor : baseColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 15));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setVerticalTextPosition(SwingConstants.CENTER);
        btn.setHorizontalTextPosition(SwingConstants.CENTER);

        // Hover repaint trigger
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.repaint(); }
        });

        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DineOrOut::new);
    }
}